// XULADP background.js v3.1
// Recibe el dataUrl desde la pestaña y dispara chrome.downloads
// NO hace fetch, NO usa FileReader — ambos inexistentes/problemáticos en service workers

chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message.type === "GUARDAR_ARCHIVO") {
    const filename = `XUL/DESCARGAVIDS/${message.videoTitle}.ts`;
    chrome.downloads.download({
      url: message.dataUrl,
      filename: filename,
      conflictAction: "uniquify",
      saveAs: false
    }, (downloadId) => {
      const tabId = sender.tab ? sender.tab.id : null;
      if (chrome.runtime.lastError) {
        const errMsg = chrome.runtime.lastError.message;
        console.error("XULADP download error:", errMsg);
        // Intentar notificar al popup (puede estar cerrado, se ignora el error)
        chrome.runtime.sendMessage({ type: "ERROR", texto: "Error al guardar: " + errMsg }).catch(() => {});
        // También notificar al content script por si el popup está cerrado
        if (tabId) chrome.tabs.sendMessage(tabId, { type: "ERROR", texto: errMsg }).catch(() => {});
      } else {
        chrome.runtime.sendMessage({ type: "DESCARGA_OK", filename: filename }).catch(() => {});
        if (tabId) chrome.tabs.sendMessage(tabId, { type: "DESCARGA_OK", filename: filename }).catch(() => {});
      }
    });
    sendResponse({ status: "OK" });
  }
  return true;
});
